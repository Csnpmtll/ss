//
//  ViewController.swift
//  randomMath
//
//  Created by student on 30/1/2562 BE.
//  Copyright © 2562 boss. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var firstNumber:UILabel!
    @IBOutlet weak var secondNumber:UILabel!
    @IBOutlet weak var operator1:UILabel!
    @IBOutlet weak var textField: UITextField!
    var first=0
    var second=0
    var operation=""
    var ans=0
    let operators = ["+","-","*","/"]
    override func viewDidLoad() {
        super.viewDidLoad()
        restart()
    }
    @IBAction func restart(){
        let num1 = Int.random(in: 1...1000)
        let num2 = Int.random(in: 1...1000)
        first = num1
        second = num2
        let operators = Int.random(in: 1...4)
        if operators == 1{
            operation="+"
            ans = num1+num2
        }else if operators == 2 {
            operation="-"
            ans = num1-num2
        }else if operators == 3 {
            operation="*"
            ans = num1*num2
        }else{
            operation="/"
            ans = num1/num2
        }
        updateLabels()
    }
    func updateLabels(){
        firstNumber.text=String(first)
        secondNumber.text=String(second)
        operator1.text=String(operation)
        textField.text=String("")
    }
    @IBAction func checkAnswer(){
        var message = ""
        let inputNum:Int? = Int(textField.text!)
        if ans == inputNum{
            message="Perfect answer"
        }else{
            message="Try again"
        }
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default , handler:{_ in self.restart()})
        alert.addAction(action)
        present(alert,animated: true,completion: nil)
    }
}

