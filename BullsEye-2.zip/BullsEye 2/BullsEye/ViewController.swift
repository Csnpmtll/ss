//
//  ViewController.swift
//  BullsEye
//
//  Created by student on 9/1/2562 BE.
//  Copyright © 2562 Boss. All rights reserved.
//

import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var slider:UISlider!
    @IBOutlet weak var targetLabel:UILabel!
    var currentValue:Int=0
    var targetValue=0
    @IBOutlet weak var scoreLabel:UILabel!
    @IBOutlet weak var roundLabel:UILabel!
    var totalscore=0
    var round=0
    override func viewDidLoad() {
        
        let thumbImageNormal = UIImage(named: "SliderThumb-Normal")!
        slider.setThumbImage(thumbImageNormal, for: .normal)
        let thumbImageHighlight = UIImage(named: "SliderThumb-Highlighted")!
        slider.setThumbImage(thumbImageHighlight, for: .highlighted)
        let insets = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
        
        let trackLeftImage = UIImage(named: "SliderTrackLeft")!
        let trackLeftResizeImage = trackLeftImage.resizableImage(withCapInsets: insets)
        slider.setMinimumTrackImage(trackLeftResizeImage, for: .normal)
        
        let trackRightImage = UIImage(named: "SliderTrackRight")!
        let trackRightResizeImage = trackRightImage.resizableImage(withCapInsets: insets)
        slider.setMaximumTrackImage(trackRightResizeImage, for: .normal)
        
        super.viewDidLoad()
        currentValue=lroundf(slider.value)
        startNewRound()
    }
    func updateLabels(){
        targetLabel.text=String(targetValue)
        scoreLabel.text=String(totalscore)
        roundLabel.text=String(round)
    }
    func startNewRound(){
        round+=1
        targetValue = Int.random(in: 1...100)
        updateLabels()
        currentValue=50
        slider.value=Float(currentValue)
    }
    @IBAction func restart(){
        totalscore=0
        round=0
        startNewRound()
        
        let transition = CATransition()
        transition.type=CATransitionType.fade
        transition.duration=0.8
        transition.timingFunction=CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
        view.layer.add(transition,forKey:nil)
        
    }
    @IBAction func showAlert(){
        let different=abs(currentValue-targetValue)
        let points = 100-different
        totalscore += points
        var bonus:Int=0
        let title:String
        if different == 0{
            bonus=100
            totalscore+=100
            title="Perfect!"
        }else if different<5{
            bonus=75
            totalscore+=75
            title="You almost had it!"
        }else if different<10{
            bonus=50
            totalscore+=50
            title="Pretty good!"
        }
        else{
            title="Not even close..."
        }
        
        let message = "The value massage of the slider is: \(currentValue)" +
        "\nThe target value is: \(targetValue)" + "\nThe difference is: \(different)" +
        "\nYour score \(points) points"+"\n You get \(bonus) bonuspoints"
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default , handler: {_ in self.startNewRound()})
        alert.addAction(action)
        present(alert,animated: true,completion: nil)
    }
    @IBAction func sliderMoved(_ slider: UISlider){
        currentValue=lroundf(slider.value)
    }

}
